import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class InventorySystemGUI extends JFrame {
    private JTable inventoryTable;
    private JTextField nameField, quantityField, priceField;
    private JButton addButton, editButton, deleteButton, refreshButton;

    public InventorySystemGUI() {
        setTitle("Inventory Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(60, 90, 180));
        headerPanel.setPreferredSize(new Dimension(900, 80));

        JLabel titleLabel = new JLabel("Inventory Management System", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        // Table Panel
        inventoryTable = new JTable(new DefaultTableModel(new Object[]{"ID", "Name", "Quantity", "Price"}, 0));
        inventoryTable.setRowHeight(30);
        inventoryTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane tableScrollPane = new JScrollPane(inventoryTable);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Inventory List"));
        tablePanel.add(tableScrollPane, BorderLayout.CENTER);

        add(tablePanel, BorderLayout.CENTER);

        // Form and Buttons Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        formPanel.setBackground(new Color(245, 245, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);

        nameField = new JTextField();
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(nameField, gbc);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(quantityLabel, gbc);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(quantityField, gbc);

        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(priceLabel, gbc);

        priceField = new JTextField();
        priceField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(priceField, gbc);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        buttonPanel.setBackground(new Color(245, 245, 245));

        addButton = createStyledButton("Add", new Color(76, 175, 80));
        editButton = createStyledButton("Edit", new Color(255, 152, 0));
        deleteButton = createStyledButton("Delete", new Color(244, 67, 54));
        refreshButton = createStyledButton("Refresh", new Color(33, 150, 243));

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.SOUTH);

        // Add Action Listeners
        addButton.addActionListener(e -> addItem());
        editButton.addActionListener(e -> editItem());
        deleteButton.addActionListener(e -> deleteItem());
        refreshButton.addActionListener(e -> refreshPage());

        // Add Table Selection Listener
        inventoryTable.getSelectionModel().addListSelectionListener(e -> populateFields());

        // Fetch Initial Data
        fetchItems();
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void addItem() {
        try {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());

            String query = "INSERT INTO inventory (name, quantity, price) VALUES (?, ?, ?)";
            try (Connection conn = DBConnection.connect();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, name);
                stmt.setInt(2, quantity);
                stmt.setDouble(3, price);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item added successfully!");
                fetchItems();
                clearFields();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check your data.");
        }
    }

    private void editItem() {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an item to edit.");
            return;
        }

        try {
            int id = (int) inventoryTable.getValueAt(selectedRow, 0);
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name cannot be empty.");
                return;
            }

            String query = "UPDATE inventory SET name = ?, quantity = ?, price = ? WHERE id = ?";
            try (Connection conn = DBConnection.connect();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, name);
                stmt.setInt(2, quantity);
                stmt.setDouble(3, price);
                stmt.setInt(4, id);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item updated successfully!");
                fetchItems();
                clearFields();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check your data.");
        }
    }

    private void deleteItem() {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.");
            return;
        }

        try {
            int id = (int) inventoryTable.getValueAt(selectedRow, 0);
            String query = "DELETE FROM inventory WHERE id = ?";
            try (Connection conn = DBConnection.connect();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item deleted successfully!");
                fetchItems();
                clearFields();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fetchItems() {
        String query = "SELECT * FROM inventory";
        DefaultTableModel model = (DefaultTableModel) inventoryTable.getModel();
        model.setRowCount(0);

        try (Connection conn = DBConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void populateFields() {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow != -1) {
            nameField.setText(inventoryTable.getValueAt(selectedRow, 1).toString());
            quantityField.setText(inventoryTable.getValueAt(selectedRow, 2).toString());
            priceField.setText(inventoryTable.getValueAt(selectedRow, 3).toString());
        }
    }

    private void clearFields() {
        nameField.setText("");
        quantityField.setText("");
        priceField.setText("");
    }

    private void refreshPage() {
        clearFields();
        fetchItems();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InventorySystemGUI().setVisible(true));
    }
}
